/*
 * Este programa calcula la media de tres números enteros
 */
package practica2_3;

/**
 *
 * @author b
 */
public class Practica2_3 {

    public static void main(String[] args) {
        int a=4,b=6,c=4;
        
        System.out.println((a + b + c) / 3.0);
    }
    
}
