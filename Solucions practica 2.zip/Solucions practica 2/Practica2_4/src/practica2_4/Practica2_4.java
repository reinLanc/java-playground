/*
 *Este programa calcula la media de tres números enteros
 */
package practica2_4;

/**
 *
 * @author 
 */
public class Practica2_4 {

    public static void main(String[] args) {
        double a = 4, b = 6.5, c = 3;
        
        System.out.println((a + b + c) / 3);
    }
    
}
