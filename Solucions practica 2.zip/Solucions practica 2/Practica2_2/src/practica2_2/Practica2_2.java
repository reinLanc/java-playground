/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package practica2_2;

/**
 *
 * @author maximo
 */
public class Practica2_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double a=4,b=6,c=3,d=5;
        
        System.out.println(a+b+c+d);
        System.out.println(a*10000);
        System.out.println(b/3);
        System.out.println((int)(c/d));
        System.out.println(a%b);
        
        
        
    }
}
